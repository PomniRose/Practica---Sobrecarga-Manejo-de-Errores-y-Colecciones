/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pregunta5;
import java.util.Scanner; // Importamos la clase Scanner para poder leer datos que nos dara el usuario desde el teclado


/**
 *
 * @author DEYVI
 */

//esta clase mostrara un mensaje cuando se detecte que el numero ingresado es negativo
class NumeroNegativoException extends Exception {
    public NumeroNegativoException(String mensaje) {
        super(mensaje);
    }
}

//clase principal
public class Pregunta5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);  //Creamos un objeto Scanner para leer datos desde la consola

        try {
            System.out.print("Ingrese un número entero: ");
            String entrada = sc.nextLine(); // Lee lo que el usuario escribe como texto

            // Intentamos convertir ese texto a un número entero
            int numero = Integer.parseInt(entrada);

            // Si el número es negativo
            if (numero < 0) {
                throw new NumeroNegativoException("Error: El número no puede ser negativo.");
            }

            // Si el numero es un entero positivo, mostramos el número ingresado
            System.out.println("Número ingresado correctamente: " + numero);

        } catch (NumberFormatException e) {// Si el usuario escribe algo que no es número
            System.out.println("Error: Debe ingresar un valor numérico entero válido.");
        } catch (NumeroNegativoException e) {
            System.out.println(e.getMessage());
        } finally {// Este bloque siempre se ejecuta, ocurra o no un error indicando que finalizo el programa
            System.out.println("Fin del programa.");
        }

        sc.close();
    }
    
}
