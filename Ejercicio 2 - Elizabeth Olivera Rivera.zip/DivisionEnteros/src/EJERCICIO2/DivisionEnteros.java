package EJERCICIO2;
import java.util.Scanner;

// Definimos la clase DivisionEnteros
public class DivisionEnteros {
    // Método principal
    public static void main(String[] args) {
        // Creamos un objeto Scanner para leer la entrada del usuario
        Scanner sc = new Scanner(System.in);
        
        // Bloque try-catch para manejar excepciones
        try {
            // Pedimos al usuario que ingrese el primer número entero
            System.out.print("Ingrese el primer número entero: ");
            // Leemos el primer número entero
            int num1 = sc.nextInt();
            
            // Pedimos al usuario que ingrese el segundo número entero
            System.out.print("Ingrese el segundo número entero: ");
            // Leemos el segundo número entero
            int num2 = sc.nextInt();
            
            // Realizamos la división y almacenamos el resultado
            int resultado = num1 / num2;
            
            // Imprimimos el resultado
            System.out.println("El resultado de la división es: " + resultado);
        } 
        // Capturamos la excepción ArithmeticException (división entre cero)
        catch (ArithmeticException e) {
            // Imprimimos un mensaje de error
            System.out.println("Error: división entre cero no permitida");
        } 
        // Capturamos cualquier otra excepción (entrada no válida, etc.)
        catch (Exception e) {
            // Imprimimos un mensaje de error
            System.out.println("Error: entrada no válida. Por favor ingrese números enteros.");
        } 
        // Bloque finally que se ejecuta siempre
        finally {
            // Cerramos el objeto Scanner
            sc.close();
        }
    }
}