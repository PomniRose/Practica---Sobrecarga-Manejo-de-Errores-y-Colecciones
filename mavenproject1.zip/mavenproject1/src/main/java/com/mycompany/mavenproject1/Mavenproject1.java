package com.mycompany.mavenproject1;


class Calculadora {


    public int sumar(int a, int b) {
        return a + b;
    }

    public int sumar(int a, int b, int c) {
        return a + b + c;
    }

    public double sumar(double x, double y) {
        return x + y;
    }
}

/**
 * Pregunta 1 – Sobrecarga de Métodos
 * Demostración de uso de Calculadora con métodos "sumar" sobrecargados.
 */
public class Mavenproject1 {

    public static void main(String[] args) {
        Calculadora calc = new Calculadora();

        int r1 = calc.sumar(7, 5);           
        int r2 = calc.sumar(3, 4, 8);        
        double r3 = calc.sumar(2.5, 4.75);   

        System.out.println("Suma 2 enteros (7 + 5): " + r1);
        System.out.println("Suma 3 enteros (3 + 4 + 8): " + r2);
        System.out.println("Suma 2 doubles (2.5 + 4.75): " + r3);
    }
}
