/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio_4;

import java.util.ArrayList;//para guardar los productos

/**
 *
 * @author Jeffrey
 */
public class Ejercicio_4 {

// Importamos la clase ArrayList del paquete java.util 
// para poder usar listas dinámicas en el almacenamiento de productos.


/**
 * Clase Producto:
 * Representa un producto dentro del inventario, con sus atributos básicos:
 * nombre, precio y cantidad.
 */
class Producto {

    // Atributos privados: encapsulan los datos del producto
    private String nombre;
    private double precio;
    private int cantidad;

    /**
     * Constructor principal.
     * Permite crear un objeto Producto asignando los tres valores: nombre, precio y cantidad.
     * @param nombre Nombre del producto.
     * @param precio Precio unitario del producto.
     * @param cantidad Cantidad disponible en el inventario.
     */
    public Producto(String nombre, double precio, int cantidad) {
        this.nombre = nombre;    // Asigna el nombre recibido al atributo de la clase
        this.precio = precio;    // Asigna el precio recibido
        this.cantidad = cantidad; // Asigna la cantidad recibida
    }

    /**
     * Constructor alternativo que recibe solo el nombre.
     * Asigna valores por defecto a precio y cantidad (0.0 y 0).
     * Ejemplo: Producto p = new Producto("Manzanas");
     */
    public Producto(String nombre) {
        this(nombre, 0.0, 0); // Llama al constructor principal con valores por defecto
    }

    /**
     * Constructor alternativo que recibe nombre y precio.
     * Asigna 0 como cantidad por defecto.
     * Ejemplo: Producto p = new Producto("Peras", 2.5);
     */
    public Producto(String nombre, double precio) {
        this(nombre, precio, 0); // Reutiliza el constructor principal
    }

    // Métodos getters: permiten acceder a los valores de los atributos privados.
    public String getNombre() { return nombre; }
    public double getPrecio() { return precio; }
    public int getCantidad() { return cantidad; }

    /**
     * Método sobrescrito toString():
     * Devuelve una representación en texto del producto, útil para mostrar en consola.
     */
    @Override
    public String toString() {
        return "Producto: " + nombre + " | Precio: " + precio + " | Cantidad: " + cantidad;
    }
}

/**
 * Clase principal Ejercicio_4:
 * Simula un inventario con una lista dinámica de productos.
 * Implementa sobrecarga de métodos para agregar productos con distintos parámetros.
 */


    // Estructura de datos para almacenar los productos del inventario.
    // ArrayList permite agregar y quitar elementos dinámicamente.
    private ArrayList<Producto> listaProductos = new ArrayList<>();

    /**
     * Método sobrecargado 1:
     * Agrega un producto recibiendo solo el nombre.
     * El precio y cantidad se establecen con valores por defecto.
     * @param nombre Nombre del producto.
     */
    public void agregarProducto(String nombre) {
        listaProductos.add(new Producto(nombre));
        System.out.println("Producto agregado solo con nombre: " + nombre);
    }

    /**
     * Método sobrecargado 2:
     * Agrega un producto con nombre y precio.
     * Verifica que el precio no sea negativo antes de agregarlo.
     * @param nombre Nombre del producto.
     * @param precio Precio unitario.
     */
    public void agregarProducto(String nombre, double precio) {
        if (precio < 0) { // Validación de errores
            System.out.println("Error: el precio no puede ser negativo.");
            return;
        }
        listaProductos.add(new Producto(nombre, precio));
        System.out.println("Producto agregado con nombre y precio: " + nombre + ", " + precio);
    }

    /**
     * Método sobrecargado 3:
     * Agrega un producto con nombre, precio y cantidad.
     * Se verifica que ninguno de los valores numéricos sea negativo.
     * @param nombre Nombre del producto.
     * @param precio Precio unitario.
     * @param cantidad Cantidad en inventario.
     */
    public void agregarProducto(String nombre, double precio, int cantidad) {
        if (precio < 0 || cantidad < 0) { // Validación de entrada
            System.out.println("Error: el precio o la cantidad no pueden ser negativos.");
            return;
        }
        listaProductos.add(new Producto(nombre, precio, cantidad));
        System.out.println("Producto agregado con nombre, precio y cantidad: "
                + nombre + ", " + precio + ", " + cantidad);
    }

    /**
     * Muestra todos los productos registrados en el inventario.
     * Si no hay productos, informa que la lista está vacía.
     */
    public void mostrarInventario() {
        System.out.println("\n=== LISTA DE PRODUCTOS ===");
        if (listaProductos.isEmpty()) { // Verifica si la lista está vacía
            System.out.println("No hay productos registrados.");
            return;
        }
        // Recorre la lista e imprime cada producto usando toString()
        for (Producto p : listaProductos) {
            System.out.println(p);
        }
    }

    /**
     * Método principal (main):
     * Punto de entrada del programa.
     * Aquí se prueban los métodos sobrecargados y la validación de datos.
     * @param args
     */
    public static void main(String[] args) {

        // Se crea una instancia de la clase para acceder a sus métodos no estáticos.
        Ejercicio_4 inv = new Ejercicio_4();

        // Demostración del uso de los métodos sobrecargados:
        inv.agregarProducto("Manzanas");                // Solo nombre
        inv.agregarProducto("Peras", 2.5);              // Nombre y precio
        inv.agregarProducto("Naranjas", 3.0, 10);       // Nombre, precio y cantidad
        inv.agregarProducto("Plátanos", -1.0, 5);       // Caso de error: precio negativo

        // Mostrar los productos almacenados
        inv.mostrarInventario();
    }
}
