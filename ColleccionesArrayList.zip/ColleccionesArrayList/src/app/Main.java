/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package app;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ArrayList<String> estudiantes = new ArrayList<>();

        System.out.println("=== Registro de estudiantes ===");

        // Agregar 5 nombres mínimos
        System.out.println("Ingresa al menos 5 nombres.");
        for (int i = 1; i <= 5; i++) {
            System.out.print("Nombre " + i + ": ");
            estudiantes.add(sc.nextLine());
        }

        // Opción para seguir agregando
        System.out.println("\n¿Quieres agregar más nombres? (s/n)");
        String respuesta = sc.nextLine();

        while (respuesta.equalsIgnoreCase("s")) {
            System.out.print("Ingresa un nombre adicional: ");
            estudiantes.add(sc.nextLine());

            System.out.println("¿Agregar otro nombre? (s/n)");
            respuesta = sc.nextLine();
        }

        // Mostrar lista completa
        System.out.println("\nLista completa de estudiantes:");
        for (String nombre : estudiantes) {
            System.out.println(nombre);
        }

        // Eliminar el tercer nombre
        if (estudiantes.size() >= 3) {
            System.out.println("\nEliminando el tercer nombre: " + estudiantes.get(2));
            estudiantes.remove(2);
        } else {
            System.out.println("\nNo se puede eliminar el tercer nombre (menos de 3 estudiantes).");
        }

        // Mostrar la lista nuevamente
        System.out.println("\nLista después de eliminar el tercer nombre:");
        for (String nombre : estudiantes) {
            System.out.println(nombre);
        }
    }
}